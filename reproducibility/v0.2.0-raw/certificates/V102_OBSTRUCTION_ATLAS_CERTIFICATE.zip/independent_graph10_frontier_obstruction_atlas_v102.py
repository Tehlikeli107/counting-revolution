from pathlib import Path
import zipfile, json, csv, hashlib, itertools, time, traceback, platform, sys, os, io
from collections import defaultdict
import numpy as np
import networkx as nx

VERSION="v102"
HERE=Path(__file__).resolve().parent
N=10
CATALOG_GRAPHS=12_005_168
FIELDS=("e1","e2","e3","e4","e5","e6","e7","e8","e9","tree")
FIELD_INDEX={f:i for i,f in enumerate(FIELDS)}
CERTS={'V75': {'bytes': 54453, 'sha': 'd585835d4d694497dc9519b116bdace8df8c47a61b71bd71e9e06b2bed40e4d8'}, 'V86': {'bytes': 8914430, 'sha': '301e77e8b55f04de5af034aee36aa62697e22fa299d1c227eeed5817aef8d2b3'}, 'V88': {'bytes': 153226, 'sha': 'b0472429a6e23698e6ccde40a7638a7ddc7a74ece24a077cacc88a9ef0d51e25'}, 'V90': {'bytes': 76891, 'sha': 'f5e9ed38cb9de172d617cb3b29d938bf5c805b5788a0fadb931092b041f32299'}, 'V91': {'bytes': 18252, 'sha': '21c9bf7f03ef01d613cac78474f8049ae0203dc40732a49d236bd651081b6f4f'}, 'V97': {'bytes': 17655, 'sha': '8d511083fa94610161df94fbe6d3427b40bb2c9427d19046e2c8b7f024eb5e6a'}, 'V98': {'bytes': 10988, 'sha': '8934c7255723200103771efacaa142371612f595b1d9b470d57b5ca185839c25'}, 'V100': {'bytes': 14802, 'sha': 'fd93ca5b3959457334fa0cccad24a782e4ab31a31618ddafd57cf8b234b34f77'}, 'V101': {'bytes': 12978, 'sha': '673a7fecba42527d6660d2de66326fc7161903d615791d8f1c7a6921a43a6aaf'}}

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1<<20),b""):
            h.update(b)
    return h.hexdigest()

def validate_zip(path,meta,manifest,versions):
    if not path.is_file():
        raise RuntimeError("missing "+path.name)
    if path.stat().st_size!=meta["bytes"]:
        raise RuntimeError("outer byte mismatch "+path.name)
    if sha256_file(path)!=meta["sha"]:
        raise RuntimeError("outer SHA mismatch "+path.name)
    with zipfile.ZipFile(path) as z:
        mani=json.loads(z.read(manifest))
        if mani.get("version") not in versions or mani.get("result")!="OK":
            raise RuntimeError("manifest mismatch "+path.name)
        expected={manifest}
        for e in mani["files"]:
            expected.add(e["path"])
            d=z.read(e["path"])
            if len(d)!=int(e["bytes"]):
                raise RuntimeError("payload byte mismatch "+path.name+" "+e["path"])
            if hashlib.sha256(d).hexdigest()!=e["sha256"]:
                raise RuntimeError("payload SHA mismatch "+path.name+" "+e["path"])
        if set(z.namelist())!=expected:
            raise RuntimeError("entry set mismatch "+path.name)

def zcsv(cert,inner):
    with zipfile.ZipFile(HERE/cert) as z:
        return list(csv.DictReader(io.StringIO(z.read(inner).decode("utf-8-sig"))))

def zjson(cert,inner):
    with zipfile.ZipFile(HERE/cert) as z:
        return json.loads(z.read(inner))

def graph6_to_masks(s):
    if len(s)!=9 or ord(s[0])-63!=N:
        raise ValueError("invalid n=10 graph6 "+repr(s))
    bits=[]
    for ch in s[1:]:
        value=ord(ch)-63
        bits.extend((value>>shift)&1 for shift in (5,4,3,2,1,0))
    masks=[0]*N
    k=0
    for j in range(1,N):
        for i in range(j):
            if bits[k]:
                masks[i]|=1<<j
                masks[j]|=1<<i
            k+=1
    return tuple(masks)

def masks_to_numpy(masks):
    a=np.zeros((N,N),dtype=np.int64)
    for i,mask in enumerate(masks):
        x=mask
        while x:
            b=x & -x
            j=b.bit_length()-1
            a[i,j]=1
            x-=b
    return a

def bareiss_det(matrix):
    a=[list(map(int,row)) for row in matrix]
    n=len(a)
    if n==0:return 1
    if n==1:return a[0][0]
    sign=1
    prev=1
    for k in range(n-1):
        if a[k][k]==0:
            swap=next((r for r in range(k+1,n) if a[r][k]!=0),None)
            if swap is None:return 0
            a[k],a[swap]=a[swap],a[k]
            sign*=-1
        pivot=a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                num=a[i][j]*pivot-a[i][k]*a[k][j]
                if k>0:
                    if num%prev:
                        raise RuntimeError("Bareiss non-exact division")
                    num//=prev
                a[i][j]=num
        prev=pivot
        for i in range(k+1,n):
            a[i][k]=0
    return sign*a[n-1][n-1]

def spanning_tree_count(a):
    if a.shape[0]<=1:return 1
    deg=a.sum(axis=1).astype(np.int64)
    L=np.diag(deg)-a
    return int(bareiss_det(L[1:,1:].tolist()))

def all_deleted_charpoly_fast(a):
    b=np.eye(N,dtype=np.int64)
    ident=np.eye(N,dtype=np.int64)
    out=[[] for _ in range(N)]
    for k in range(1,N):
        ab=a@b
        tr=int(np.trace(ab))
        if tr%k:
            raise RuntimeError("Faddeev-LeVerrier non-exact division")
        coeff=-(tr//k)
        b=ab+coeff*ident
        diag=np.diag(b)
        sign=-1 if k%2 else 1
        for v in range(N):
            out[v].append(sign*int(diag[v]))
    return [tuple(x) for x in out]

def full_atomic_records(g6):
    a=masks_to_numpy(graph6_to_masks(g6))
    deleted=all_deleted_charpoly_fast(a)
    out=[]
    for v in range(N):
        keep=[i for i in range(N) if i!=v]
        tree=spanning_tree_count(a[np.ix_(keep,keep)])
        out.append(tuple(deleted[v])+(tree,))
    return tuple(out)

def component(records,fields):
    inds=tuple(FIELD_INDEX[f] for f in fields)
    return tuple(sorted(tuple(rec[i] for i in inds) for rec in records))

def comp_sha(comp):
    raw=json.dumps(comp,separators=(",",":"),ensure_ascii=True).encode()
    return hashlib.sha256(raw).hexdigest()

def pairwise_noniso(graph6s):
    G=[nx.from_graph6_bytes(g.encode("ascii")) for g in graph6s]
    checks=0
    for i,j in itertools.combinations(range(len(G)),2):
        checks+=1
        if nx.is_isomorphic(G[i],G[j]):
            return False,checks
    return True,checks

def validate_sources():
    specs=[
        ("V75","V75_CERTIFICATE.zip","v75_manifest.json",{"v75"}),
        ("V86","V86_CERTIFICATE.zip","v86_manifest.json",{"v86.1"}),
        ("V88","V88_CERTIFICATE.zip","v88_manifest.json",{"v88"}),
        ("V90","V90_CERTIFICATE.zip","v90_manifest.json",{"v90"}),
        ("V91","V91_CERTIFICATE.zip","v91_manifest.json",{"v91"}),
        ("V97","V97_CERTIFICATE.zip","v97_manifest.json",{"v97.1"}),
        ("V98","V98_CERTIFICATE.zip","v98_manifest.json",{"v98"}),
        ("V100","V100_CERTIFICATE.zip","v100_manifest.json",{"v100"}),
        ("V101","V101_CERTIFICATE.zip","v101_manifest.json",{"v101"}),
    ]
    for key,cert,mani,vers in specs:
        validate_zip(HERE/cert,CERTS[key],mani,vers)

def source_rows():
    e4=zcsv("V86_CERTIFICATE.zip","largest_e4_only_collision_class.csv")
    tree=zcsv("V86_CERTIFICATE.zip","tree_only_3991_all_zero_lower_bound_witness.csv")
    e2=zcsv("V88_CERTIFICATE.zip","largest_e2_class_sample.csv")
    e3=zcsv("V90_CERTIFICATE.zip","e3_all_zero_witness.csv")
    e5=zcsv("V90_CERTIFICATE.zip","e5_all_zero_witness.csv")
    e7=zcsv("V90_CERTIFICATE.zip","e7_all_zero_witness.csv")
    e8=zcsv("V90_CERTIFICATE.zip","e8_all_zero_witness.csv")
    e9=zcsv("V90_CERTIFICATE.zip","e9_all_zero_witness.csv")
    e24=zcsv("V91_CERTIFICATE.zip","largest_e4_e2_collision_class.csv")
    e23=zcsv("V97_CERTIFICATE.zip","largest_e2_e3_collision_class.csv")
    e2tree=zcsv("V98_CERTIFICATE.zip","e2_tree_size63_obstruction_witness.csv")
    return {
        "e4":e4,"tree":tree,"e2":e2,"e3":e3,"e5":e5,
        "e7":e7,"e8":e8,"e9":e9,
        "e2+e4":e24,"e2+e3":e23,"e2+tree":e2tree,
    }

def choose_single_witnesses(src):
    pools={
        "e1":src["e4"],
        "e2":src["e2"],
        "e3":src["e3"],
        "e4":src["e4"],
        "e5":src["e5"],
        "e6":src["e7"], # V90's 3023 e7 witness is the V89 e6-largest class.
        "e7":src["e7"],
        "e8":src["e8"],
        "e9":src["e9"],
        "tree":src["tree"],
    }
    result={}
    for field,pool in pools.items():
        if len(pool)<33:
            raise RuntimeError(f"single witness pool too small {field}")
        rows=[]
        for r in pool[:33]:
            rows.append((int(r["catalog_index"]),r["graph6"]))
        result[field]=rows
    return result

def build_v90_cache(src):
    rows=src["e7"]
    if len(rows)!=3023:
        raise RuntimeError("V90 3023 witness changed")
    cache={}
    g6={}
    for r in rows:
        idx=int(r["catalog_index"])
        cache[idx]=full_atomic_records(r["graph6"])
        g6[idx]=r["graph6"]
    return cache,g6

def largest_bucket(cache,fields):
    buckets={}
    for idx,rec in cache.items():
        c=component(rec,fields)
        buckets.setdefault(c,[]).append(idx)
    comp,members=max(buckets.items(),key=lambda kv:(len(kv[1]),kv[1]))
    return comp,sorted(members)

def choose_pair_witnesses(src,cache,g6cache):
    result={}
    for fields in itertools.combinations(FIELDS,2):
        name="+".join(fields)
        if name=="e2+e4":
            rows=src["e2+e4"]
            chosen=[(int(r["catalog_index"]),r["graph6"]) for r in rows[:5]]
            source="V91 exact size-10 class"
        elif name=="e2+e3":
            rows=src["e2+e3"]
            chosen=[(int(r["catalog_index"]),r["graph6"]) for r in rows[:5]]
            source="V97 exact size-393 class"
        elif name=="e2+tree":
            rows=src["e2+tree"]
            chosen=[(int(r["catalog_index"]),r["graph6"]) for r in rows[:5]]
            source="V98 explicit size-63 class"
        else:
            comp,members=largest_bucket(cache,fields)
            if len(members)<5:
                raise RuntimeError(f"V90 adversarial pool lacks size-5 pair obstruction {name}: {len(members)}")
            chosen=[(idx,g6cache[idx]) for idx in members[:5]]
            source=f"V90 3023-graph adversarial pool; observed class size {len(members)}"
        result[name]={"fields":fields,"chosen":chosen,"source":source}
    return result

def verify_single(single):
    atlas=[]
    total_iso=0
    for field,rows in single.items():
        comps=[]
        g6s=[]
        for idx,g6 in rows:
            rec=full_atomic_records(g6)
            comps.append(component(rec,(field,)))
            g6s.append(g6)
        if not all(c==comps[0] for c in comps):
            raise RuntimeError("single component mismatch "+field)
        ok,checks=pairwise_noniso(g6s)
        if not ok or checks!=528:
            raise RuntimeError("single noniso mismatch "+field)
        total_iso+=checks
        sh=comp_sha(comps[0])
        sig=json.dumps(comps[0],separators=(",",":"))
        for rank,(idx,g6) in enumerate(rows,1):
            atlas.append({
                "field":field,"witness_rank":rank,"catalog_index":idx,
                "graph6":g6,"shared_signature":sig,
                "shared_signature_sha256":sh,
            })
    return atlas,total_iso

def verify_pairs(pairs):
    atlas=[]
    summary=[]
    total_iso=0
    for name,item in pairs.items():
        fields=item["fields"]
        chosen=item["chosen"]
        comps=[]
        g6s=[]
        for idx,g6 in chosen:
            rec=full_atomic_records(g6)
            comps.append(component(rec,fields))
            g6s.append(g6)
        if not all(c==comps[0] for c in comps):
            raise RuntimeError("pair component mismatch "+name)
        ok,checks=pairwise_noniso(g6s)
        if not ok or checks!=10:
            raise RuntimeError("pair noniso mismatch "+name)
        total_iso+=checks
        sh=comp_sha(comps[0])
        sig=json.dumps(comps[0],separators=(",",":"))
        summary.append({
            "pair":name,
            "explicit_witness_size":5,
            "shared_signature_sha256":sh,
            "source":item["source"],
            "arbitrary_1_bit_impossible":True,
            "arbitrary_2_bit_impossible":True,
        })
        for rank,(idx,g6) in enumerate(chosen,1):
            atlas.append({
                "pair":name,"witness_rank":rank,"catalog_index":idx,
                "graph6":g6,"shared_signature":sig,
                "shared_signature_sha256":sh,"source":item["source"],
            })
    return atlas,summary,total_iso

def main():
    outdir=None
    started=time.time()
    try:
        validate_sources()
        print("[CERT] 9/9 exact source certificates")
        src=source_rows()

        # Cross-check the frozen frontier.
        v101=zjson("V101_CERTIFICATE.zip","INFORMATION_FRONTIER_THEOREM.json")
        if v101["frontier_vector"]!=[5,3,3,2,2,2,1]:
            raise RuntimeError("V101 frontier changed")

        print("[PAIR] recomputing 3023-graph atomic cache")
        cache,g6cache=build_v90_cache(src)

        print("[PAIR] constructing 45 explicit size-5 obstruction sets")
        pairs=choose_pair_witnesses(src,cache,g6cache)
        pair_atlas,pair_summary,pair_iso=verify_pairs(pairs)
        if len(pair_summary)!=45 or len(pair_atlas)!=225 or pair_iso!=450:
            raise RuntimeError("pair atlas cardinality mismatch")

        print("[SINGLE] constructing 10 explicit size-33 obstruction sets")
        single=choose_single_witnesses(src)
        single_atlas,single_iso=verify_single(single)
        if len(single_atlas)!=330 or single_iso!=5280:
            raise RuntimeError("single atlas cardinality mismatch")

        # Explicit obstruction logic.
        # size 5 rules out arbitrary 1-bit (2 states) and 2-bit (4 states) repair.
        # size 33 rules out arbitrary 3/4/5-bit repair of a single field
        # because capacities are 8,16,32.
        theorem={
            "version":VERSION,
            "catalog_graphs":CATALOG_GRAPHS,
            "atomic_family":list(FIELDS),
            "frozen_frontier_from_V101":[5,3,3,2,2,2,1],
            "pair_obstruction_atlas":{
                "atomic_pairs":45,
                "explicit_graphs_per_pair":5,
                "total_explicit_graph_rows":225,
                "pairwise_nonisomorphism_checks":pair_iso,
                "all_45_verified_same_aligned_pair_signature":True,
                "consequence":"Every atomic pair has an explicit collision class of size at least 5. Therefore no arbitrary deterministic 1-bit or 2-bit side channel can repair any atomic pair.",
                "capacity_comparison":{"1_bit":2,"2_bits":4,"witness_size":5},
            },
            "single_field_obstruction_atlas":{
                "atomic_fields":10,
                "explicit_graphs_per_field":33,
                "total_explicit_graph_rows":330,
                "pairwise_nonisomorphism_checks":single_iso,
                "all_10_verified_same_single_field_signature":True,
                "consequence":"Every atomic single-field base has an explicit collision class of size at least 33. Therefore no arbitrary deterministic 3-bit, 4-bit, or 5-bit channel can repair any single field.",
                "capacity_comparison":{"3_bits":8,"4_bits":16,"5_bits":32,"witness_size":33},
                "note":"V90/V90.1 provide stronger exact/lower state bounds (best single e4 requires 57 states); the 33-graph atlas is a compact explicit obstruction sufficient for the 3..5-bit field-count lower bounds."
            },
            "other_frontier_lower_bounds":{
                "0_bits":"V75 exhaustively proves all atomic subsets of size <=4 incomplete; this lower bound is exhaustive-lattice based rather than represented by a single universal obstruction set.",
                "6_bits_zero_fields":"With zero atomic fields, a 6-bit channel has at most 64 outputs for 12,005,168 graphs; counting alone rules out zero fields."
            },
            "upper_bounds_from_frozen_frontier":{
                "0_bits":"V75 five-field complete subset",
                "1_bit":"V94 explicit e2+e4+e6+h",
                "2_bits":"V92 e2+e4+tree max class 4",
                "3_bits":"V100 e2+e6 max class 7",
                "4_bits":"V91 e2+e4 max class 10",
                "5_bits":"V91 e2+e4 max class 10",
                "6_bits":"V90/V90.1 e4 max class 57",
            },
            "claim_scope":"Exact finite n=10 obstruction atlas for the explicit deleted-card atomic family {e1..e9,tree}. Pair records preserve within-card field alignment. Impossibility consequences allow arbitrary deterministic side channels of the stated bit width. This is not a general graph-isomorphism or reconstruction theorem.",
            "next_phase":"Use this atlas together with V101 as the self-contained evidence layer for paper/reproducibility consolidation and literature/novelty calibration; do not resume serial full-catalog scans without a specific theorem gap.",
            "elapsed_seconds":time.time()-started,
        }

        outdir=HERE/f"V102_COUNTING_REVOLUTION_GRAPH10_FRONTIER_OBSTRUCTION_ATLAS_{time.strftime('%Y%m%d_%H%M%S')}"
        outdir.mkdir()

        (outdir/"FRONTIER_OBSTRUCTION_ATLAS_THEOREM.json").write_text(
            json.dumps(theorem,indent=2),encoding="utf-8"
        )

        with (outdir/"PAIR_SIZE5_OBSTRUCTION_ATLAS.csv").open("w",encoding="utf-8",newline="") as f:
            fields=["pair","witness_rank","catalog_index","graph6","shared_signature","shared_signature_sha256","source"]
            w=csv.DictWriter(f,fieldnames=fields,lineterminator="\n")
            w.writeheader(); w.writerows(pair_atlas)

        with (outdir/"PAIR_OBSTRUCTION_SUMMARY.csv").open("w",encoding="utf-8",newline="") as f:
            fields=["pair","explicit_witness_size","shared_signature_sha256","source",
                    "arbitrary_1_bit_impossible","arbitrary_2_bit_impossible"]
            w=csv.DictWriter(f,fieldnames=fields,lineterminator="\n")
            w.writeheader(); w.writerows(pair_summary)

        with (outdir/"SINGLE_SIZE33_OBSTRUCTION_ATLAS.csv").open("w",encoding="utf-8",newline="") as f:
            fields=["field","witness_rank","catalog_index","graph6","shared_signature","shared_signature_sha256"]
            w=csv.DictWriter(f,fieldnames=fields,lineterminator="\n")
            w.writeheader(); w.writerows(single_atlas)

        md="""# Counting Revolution V102 — frontier obstruction atlas

V101 freezes the exact finite-n=10 field-count frontier:

`[5,3,3,2,2,2,1]` for auxiliary budgets `0..6`.

V102 turns the main information-theoretic lower bounds into compact explicit
graph witnesses.

## Atomic pairs

For every one of the 45 atomic pairs, V102 stores **five pairwise
non-isomorphic graphs with exactly the same aligned two-field deleted-card
signature**.

Therefore every pair has a collision class of size at least 5.

This directly rules out:

- pair + arbitrary 1 bit (2 states)
- pair + arbitrary 2 bits (4 states)

by the pigeonhole principle.

## Single atomic fields

For every one of the 10 atomic fields, V102 stores **33 pairwise
non-isomorphic graphs with the same single-field deleted-card signature**.

Therefore every single field has a collision class of size at least 33.

This directly rules out:

- single field + arbitrary 3 bits (8 states)
- single field + arbitrary 4 bits (16 states)
- single field + arbitrary 5 bits (32 states)

V90/V90.1 give the stronger global single-field result that the unique best
single field `e4` still requires 57 states.

## Scope

All statements are exact only for the complete finite `n=10` catalog and the
explicit atomic family `{e1,...,e9,tree}`.
"""
        (outdir/"FRONTIER_OBSTRUCTION_ATLAS_THEOREM.md").write_text(md,encoding="utf-8")

        (outdir/"source_provenance.json").write_text(
            json.dumps({k.lower():{"bytes":v["bytes"],"sha256":v["sha"]} for k,v in CERTS.items()},indent=2),
            encoding="utf-8"
        )
        (outdir/"environment.json").write_text(
            json.dumps({
                "platform":platform.platform(),"python":sys.version,
                "numpy":np.__version__,"networkx":nx.__version__,
                "logical_cpu_count":os.cpu_count(),
                "pair_nonisomorphism_checks":pair_iso,
                "single_nonisomorphism_checks":single_iso,
            },indent=2),encoding="utf-8"
        )

        import shutil
        shutil.copy2(Path(__file__),outdir/"independent_graph10_frontier_obstruction_atlas_v102.py")

        entries=[]
        for fp in sorted(outdir.iterdir()):
            if fp.name!="v102_manifest.json":
                entries.append({"path":fp.name,"bytes":fp.stat().st_size,"sha256":sha256_file(fp)})
        (outdir/"v102_manifest.json").write_text(
            json.dumps({"version":VERSION,"result":"OK","files":entries},indent=2),encoding="utf-8"
        )

        zout=HERE/f"{outdir.name}.zip"
        with zipfile.ZipFile(zout,"w",zipfile.ZIP_DEFLATED,allowZip64=True) as z:
            for fp in sorted(outdir.iterdir()):
                z.write(fp,fp.name)

        print("="*78)
        print("COUNTING REVOLUTION GRAPH10 FRONTIER OBSTRUCTION ATLAS V102")
        print("[SOURCE CERTIFICATES] 9 / 9 exact")
        print("[PAIR ATLAS] 45 pairs x 5 graphs = 225 rows")
        print("[PAIR NONISO CHECKS]",pair_iso)
        print("[SINGLE ATLAS] 10 fields x 33 graphs = 330 rows")
        print("[SINGLE NONISO CHECKS]",single_iso)
        print("[FRONTIER]",theorem["frozen_frontier_from_V101"])
        print("[ZIP]",zout)
        print("="*78)
        return 0

    except Exception as exc:
        try:
            if outdir is not None:
                (outdir/"ERROR.json").write_text(
                    json.dumps({"version":VERSION,"result":"ERROR","error":str(exc),"traceback":traceback.format_exc()},indent=2),
                    encoding="utf-8"
                )
        except Exception:
            pass
        print("[FATAL]",exc)
        traceback.print_exc()
        return 1

if __name__=="__main__":
    raise SystemExit(main())
