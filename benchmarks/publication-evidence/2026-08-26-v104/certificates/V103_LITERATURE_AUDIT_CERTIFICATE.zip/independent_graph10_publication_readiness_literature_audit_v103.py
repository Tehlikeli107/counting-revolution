from pathlib import Path
import zipfile, json, hashlib, shutil, time, traceback, platform, sys

VERSION="v103"
HERE=Path(__file__).resolve().parent
CERTS={'V101': {'bytes': 12978, 'sha256': '673a7fecba42527d6660d2de66326fc7161903d615791d8f1c7a6921a43a6aaf'}, 'V102': {'bytes': 15626, 'sha256': 'd61ec14b151c25e820e892e014878f35fdb41a43dd154a2053e2672d698274f6'}}
STATIC_FILES=[
"PRELIMINARY_LITERATURE_NOVELTY_AUDIT.md",
"CLAIM_NOVELTY_MATRIX.csv",
"REFERENCES.bib",
"PAPER_OUTLINE.md",
"REPRODUCIBILITY_RELEASE_CHECKLIST.md",
]

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1<<20),b""):
            h.update(b)
    return h.hexdigest()

def validate_zip(path,meta,manifest,version):
    if path.stat().st_size!=meta["bytes"] or sha256_file(path)!=meta["sha256"]:
        raise RuntimeError("outer certificate identity mismatch: "+path.name)
    with zipfile.ZipFile(path) as z:
        m=json.loads(z.read(manifest))
        if m.get("version")!=version or m.get("result")!="OK":
            raise RuntimeError("manifest status mismatch: "+path.name)
        expected={manifest}
        for e in m["files"]:
            expected.add(e["path"])
            d=z.read(e["path"])
            if len(d)!=int(e["bytes"]) or hashlib.sha256(d).hexdigest()!=e["sha256"]:
                raise RuntimeError("payload mismatch: "+path.name+" "+e["path"])
        if set(z.namelist())!=expected:
            raise RuntimeError("entry set mismatch: "+path.name)
        return z.namelist()

def main():
    outdir=None
    try:
        validate_zip(HERE/"V101_CERTIFICATE.zip",CERTS["V101"],"v101_manifest.json","v101")
        validate_zip(HERE/"V102_CERTIFICATE.zip",CERTS["V102"],"v102_manifest.json","v102")

        with zipfile.ZipFile(HERE/"V101_CERTIFICATE.zip") as z:
            frontier=json.loads(z.read("INFORMATION_FRONTIER_THEOREM.json"))
        with zipfile.ZipFile(HERE/"V102_CERTIFICATE.zip") as z:
            atlas=json.loads(z.read("FRONTIER_OBSTRUCTION_ATLAS_THEOREM.json"))

        if frontier["frontier_vector"] != [5,3,3,2,2,2,1]:
            raise RuntimeError("V101 frontier changed")
        if atlas["frozen_frontier_from_V101"] != [5,3,3,2,2,2,1]:
            raise RuntimeError("V102 frontier changed")
        if atlas["pair_obstruction_atlas"]["atomic_pairs"] != 45:
            raise RuntimeError("V102 pair atlas changed")
        if atlas["single_field_obstruction_atlas"]["atomic_fields"] != 10:
            raise RuntimeError("V102 single atlas changed")

        outdir=HERE/f"V103_COUNTING_REVOLUTION_GRAPH10_PUBLICATION_READINESS_LITERATURE_AUDIT_{time.strftime('%Y%m%d_%H%M%S')}"
        outdir.mkdir()

        for name in STATIC_FILES:
            shutil.copy2(HERE/name,outdir/name)

        summary={
            "version":VERSION,
            "result":"OK",
            "validated_certificates":["V101","V102"],
            "frozen_frontier":[5,3,3,2,2,2,1],
            "literature_snapshot_date":"2026-08-26",
            "novelty_status":"Potentially novel specific finite-n=10 frontier/certificate architecture; direct prior match not found in the searched literature, but novelty/priority is not established conclusively.",
            "closest_prior_computational_work":"Dehmer, Emmert-Streib & Grabner (Information Sciences, 2014), complete multivariate graph invariant on exhaustive connected n=9/n=10 graphs.",
            "publication_status":"Ready for manuscript/release consolidation; not yet ready for first/novel/world-first priority claims.",
        }
        (outdir/"PUBLICATION_READINESS_SUMMARY.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")

        (outdir/"source_provenance.json").write_text(json.dumps({
            "v101":CERTS["V101"],
            "v102":CERTS["V102"],
        },indent=2),encoding="utf-8")
        (outdir/"environment.json").write_text(json.dumps({
            "platform":platform.platform(),"python":sys.version
        },indent=2),encoding="utf-8")

        shutil.copy2(Path(__file__),outdir/"independent_graph10_publication_readiness_literature_audit_v103.py")

        entries=[]
        for fp in sorted(outdir.iterdir()):
            if fp.name!="v103_manifest.json":
                entries.append({"path":fp.name,"bytes":fp.stat().st_size,"sha256":sha256_file(fp)})
        (outdir/"v103_manifest.json").write_text(json.dumps({
            "version":VERSION,"result":"OK","files":entries
        },indent=2),encoding="utf-8")

        zout=HERE/f"{outdir.name}.zip"
        with zipfile.ZipFile(zout,"w",zipfile.ZIP_DEFLATED) as z:
            for fp in sorted(outdir.iterdir()):
                z.write(fp,fp.name)

        print("="*78)
        print("COUNTING REVOLUTION GRAPH10 PUBLICATION READINESS / LITERATURE AUDIT V103")
        print("[V101] exact")
        print("[V102] exact")
        print("[FRONTIER] [5,3,3,2,2,2,1]")
        print("[NOVELTY] direct prior match not found; priority NOT established")
        print("[CLOSEST PRIOR] Dehmer et al. 2014 complete multivariate n=9/n=10 invariant")
        print("[STATUS] ready for manuscript/release consolidation")
        print("[ZIP]",zout)
        print("="*78)
        return 0
    except Exception as exc:
        print("[FATAL]",exc)
        traceback.print_exc()
        return 1

if __name__=="__main__":
    raise SystemExit(main())
