from pathlib import Path
import zipfile, json, csv, hashlib, math, time, traceback, platform, sys, os

VERSION="v101"
HERE=Path(__file__).resolve().parent
CATALOG_GRAPHS=12_005_168
ATOMIC_FIELDS=["e1","e2","e3","e4","e5","e6","e7","e8","e9","tree"]
CERTS={'V75': {'bytes': 54453, 'sha': 'd585835d4d694497dc9519b116bdace8df8c47a61b71bd71e9e06b2bed40e4d8'}, 'V90': {'bytes': 76891, 'sha': 'f5e9ed38cb9de172d617cb3b29d938bf5c805b5788a0fadb931092b041f32299'}, 'V90_1': {'bytes': 6524, 'sha': '89b45b9c6efef26b29d1113f6e736fcc255e3e856a65f03259d63ea8cdb25583'}, 'V91': {'bytes': 18252, 'sha': '21c9bf7f03ef01d613cac78474f8049ae0203dc40732a49d236bd651081b6f4f'}, 'V92': {'bytes': 793997, 'sha': '4086dddf8e31e1bc43f288ab53a719deddb8f70413004c69418ecf89e0ecce02'}, 'V94': {'bytes': 13169, 'sha': '8e69f2bb2afb88961e256dfd4d49c5f6fa43047c97f2af78af06b3e1faf236a7'}, 'V96': {'bytes': 13811, 'sha': 'b6e87b449f5be412d05a41658be110878b0b0cf3e56d975eb87a653e85ab1290'}, 'V98': {'bytes': 10988, 'sha': '8934c7255723200103771efacaa142371612f595b1d9b470d57b5ca185839c25'}, 'V100': {'bytes': 14802, 'sha': 'fd93ca5b3959457334fa0cccad24a782e4ab31a31618ddafd57cf8b234b34f77'}}

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1<<20),b""):
            h.update(b)
    return h.hexdigest()

def validate_zip(path,meta,manifest,versions):
    if not path.is_file():
        raise RuntimeError("missing "+path.name)
    if path.stat().st_size!=meta["bytes"]:
        raise RuntimeError("outer byte mismatch "+path.name)
    if sha256_file(path)!=meta["sha"]:
        raise RuntimeError("outer SHA mismatch "+path.name)
    with zipfile.ZipFile(path) as z:
        mani=json.loads(z.read(manifest))
        if mani.get("version") not in versions or mani.get("result")!="OK":
            raise RuntimeError("manifest mismatch "+path.name)
        expected={manifest}
        for e in mani["files"]:
            expected.add(e["path"])
            d=z.read(e["path"])
            if len(d)!=int(e["bytes"]):
                raise RuntimeError("payload bytes "+path.name+" "+e["path"])
            if hashlib.sha256(d).hexdigest()!=e["sha256"]:
                raise RuntimeError("payload SHA "+path.name+" "+e["path"])
        if set(z.namelist())!=expected:
            raise RuntimeError("entry set mismatch "+path.name)

def read_json(cert_name,inner):
    with zipfile.ZipFile(HERE/cert_name) as z:
        return json.loads(z.read(inner))

def main():
    outdir=None
    started=time.time()
    try:
        checks=[
            ("V75_CERTIFICATE.zip","v75_manifest.json",{"v75"}),
            ("V90_CERTIFICATE.zip","v90_manifest.json",{"v90"}),
            ("V90_1_CERTIFICATE.zip","v90_1_manifest.json",{"v90.1"}),
            ("V91_CERTIFICATE.zip","v91_manifest.json",{"v91"}),
            ("V92_CERTIFICATE.zip","v92_manifest.json",{"v92"}),
            ("V94_CERTIFICATE.zip","v94_manifest.json",{"v94"}),
            ("V96_CERTIFICATE.zip","v96_manifest.json",{"v96"}),
            ("V98_CERTIFICATE.zip","v98_manifest.json",{"v98"}),
            ("V100_CERTIFICATE.zip","v100_manifest.json",{"v100"}),
        ]
        for key,(cert,mani,vers) in zip(CERTS,checks):
            validate_zip(HERE/cert,CERTS[key],mani,vers)
        print("[CERT] 9/9 source certificates exact")

        v75=read_json("V75_CERTIFICATE.zip","full_boolean_lattice_summary.json")
        v90=read_json("V90_CERTIFICATE.zip","ATOMIC_SINGLE_FIELD_CLOSURE_THEOREM.json")
        v901=read_json("V90_1_CERTIFICATE.zip","RANK_PROOF_CORRECTION_THEOREM.json")
        v91=read_json("V91_CERTIFICATE.zip","E4_CENTERED_PAIR_FRONTIER_THEOREM.json")
        v92=read_json("V92_CERTIFICATE.zip","E4_E2_CENTERED_TRIPLE_FRONTIER_THEOREM.json")
        v94=read_json("V94_CERTIFICATE.zip","COMPACT_MOD127_ONE_BIT_CHANNEL_THEOREM.json")
        v96=read_json("V96_CERTIFICATE.zip","GLOBAL_ATOMIC_PAIR_ONE_BIT_IMPOSSIBILITY_THEOREM.json")
        v98=read_json("V98_CERTIFICATE.zip","GLOBAL_TWO_BIT_FIELD_COUNT_OPTIMALITY_THEOREM.json")
        v100=read_json("V100_CERTIFICATE.zip","GLOBAL_THREE_BIT_PAIR_CANDIDATE_CLOSURE_THEOREM.json")

        # Exact source assertions.
        byk={int(k):int(v) for k,v in v75["global_complete_by_k"].items()}
        if byk[4]!=0 or byk[5]!=5:
            raise RuntimeError("V75 minimum pure-field result changed")

        if v90["closure"]["unique_best_single_atomic_field"]!="e4":
            raise RuntimeError("V90 unique-best single field changed")
        if v90["closure"]["e4_exact_min_auxiliary_states"]!=57:
            raise RuntimeError("V90 e4 exact state count changed")
        if not v901["single_field_closure"]["v90_witness_lower_bounds_preserved"]:
            raise RuntimeError("V90.1 correction closure changed")
        if v901["single_field_closure"]["e4_exact_states"]!=57:
            raise RuntimeError("V90.1 e4 exact states changed")

        if v91["best_by_auxiliary_state_count"]!={"states":10,"pairs":["e4+e2"]}:
            raise RuntimeError("V91 best e4-centered pair changed")

        triple_best=v92["best_by_auxiliary_state_count"]
        if triple_best["states"]!=2:
            raise RuntimeError("V92 one-bit triple state count changed")
        triple_tree=next(r for r in v92["exact_results"] if r["triple"]=="e4+e2+tree")
        if triple_tree["maximum_collision_class_size"]!=4:
            raise RuntimeError("V92 e2+e4+tree max class changed")

        if not v94["global_injectivity"]["globally_collision_free"]:
            raise RuntimeError("V94 explicit one-bit construction changed")
        if v94["global_injectivity"]["exact_auxiliary_width_bits"]!=1:
            raise RuntimeError("V94 one-bit width changed")

        if v96["field_count_optimality_with_one_bit"]["minimum_number_of_atomic_fields_when_exactly_one_auxiliary_bit_is_allowed"]!=3:
            raise RuntimeError("V96 one-bit field-count optimum changed")

        if v98["exact_two_bit_field_count_optimum"]["minimum_atomic_field_count_with_two_auxiliary_bits"]!=3:
            raise RuntimeError("V98 two-bit field-count optimum changed")

        if v100["global_three_bit_field_count"]["minimum_atomic_field_count_with_three_auxiliary_bits"]!=2:
            raise RuntimeError("V100 three-bit field-count optimum changed")
        if v100["global_three_bit_field_count"]["achieving_pair"]!="e2+e6":
            raise RuntimeError("V100 achieving pair changed")
        e26=next(r for r in v100["exact_candidate_results"] if r["pair"]=="e2+e6")
        if e26["maximum_collision_class_size"]!=7:
            raise RuntimeError("V100 e2+e6 exact max changed")

        # Build exact frontier 0..6.
        frontier=[
            {
                "aux_bits":0,
                "capacity_states":1,
                "minimum_atomic_fields":5,
                "lower_bound":"V75: all atomic subsets of size <=4 are globally incomplete.",
                "upper_bound":"V75: five inclusion-minimal complete 5-field subsets exist.",
                "achieving_base":"e2+e3+e4+e6+tree (one of five witnesses)",
                "certificate":"V75",
            },
            {
                "aux_bits":1,
                "capacity_states":2,
                "minimum_atomic_fields":3,
                "lower_bound":"V96: all 45 atomic pairs have explicit collision class size >=3, so arbitrary 1 bit cannot repair any pair.",
                "upper_bound":"V94: e2+e4+e6 plus one explicit mod-127-derived bit is globally injective.",
                "achieving_base":"e2+e4+e6",
                "certificate":"V96 lower + V94 upper",
            },
            {
                "aux_bits":2,
                "capacity_states":4,
                "minimum_atomic_fields":3,
                "lower_bound":"V98: all 45 atomic pairs have certified collision class size >=5, so arbitrary 2 bits cannot repair any pair.",
                "upper_bound":"V92/V98: e2+e4+tree has exact maximum class 4.",
                "achieving_base":"e2+e4+tree",
                "certificate":"V98 lower + V92 upper",
            },
            {
                "aux_bits":3,
                "capacity_states":8,
                "minimum_atomic_fields":2,
                "lower_bound":"V90/V90.1: unique-best single field e4 still needs 57 states, so 8 states cannot repair any single field.",
                "upper_bound":"V100: e2+e6 has exact maximum class 7.",
                "achieving_base":"e2+e6",
                "certificate":"V90.1 lower + V100 upper",
            },
            {
                "aux_bits":4,
                "capacity_states":16,
                "minimum_atomic_fields":2,
                "lower_bound":"V90/V90.1: every single field needs at least 57 states; 16 states are insufficient.",
                "upper_bound":"V91: e2+e4 has exact maximum class 10.",
                "achieving_base":"e2+e4",
                "certificate":"V90.1 lower + V91 upper",
            },
            {
                "aux_bits":5,
                "capacity_states":32,
                "minimum_atomic_fields":2,
                "lower_bound":"V90/V90.1: every single field needs at least 57 states; 32 states are insufficient.",
                "upper_bound":"V91: e2+e4 has exact maximum class 10.",
                "achieving_base":"e2+e4",
                "certificate":"V90.1 lower + V91 upper",
            },
            {
                "aux_bits":6,
                "capacity_states":64,
                "minimum_atomic_fields":1,
                "lower_bound":"With zero atomic fields, a 6-bit channel has only 64 outputs for 12,005,168 graphs, so injectivity is impossible.",
                "upper_bound":"V90/V90.1: e4 exact maximum class is 57 <=64.",
                "achieving_base":"e4",
                "certificate":"counting lower + V90.1 upper",
            },
        ]

        expected=[5,3,3,2,2,2,1]
        got=[r["minimum_atomic_fields"] for r in frontier]
        if got!=expected:
            raise RuntimeError("frontier vector mismatch")

        # Pareto transitions only.
        transitions=[
            {"from_bits":0,"to_bits":1,"field_count":3,"meaning":"one auxiliary bit saves two atomic fields relative to pure atomic completeness"},
            {"from_bits":2,"to_bits":3,"field_count":2,"meaning":"third auxiliary bit is the threshold that permits a two-field atomic base"},
            {"from_bits":5,"to_bits":6,"field_count":1,"meaning":"sixth auxiliary bit is the threshold that permits a single atomic field"},
        ]

        theorem={
            "version":VERSION,
            "catalog_graphs":CATALOG_GRAPHS,
            "atomic_family":ATOMIC_FIELDS,
            "frontier_definition":"For each fixed auxiliary bit budget b in {0,...,6}, minimize the number of atomic deleted-card fields among {e1,...,e9,tree} required for global injectivity on the complete n=10 non-isomorphic simple-graph catalog. Auxiliary channels in lower-bound impossibility statements may be arbitrary deterministic b-bit channels; upper bounds use either explicit channels or finite-catalog class-rank channels as stated.",
            "exact_frontier_0_to_6_bits":frontier,
            "frontier_vector":[5,3,3,2,2,2,1],
            "thresholds":{
                "first_budget_allowing_three_fields":1,
                "first_budget_allowing_two_fields":3,
                "first_budget_allowing_one_field":6,
            },
            "constructive_highlights":{
                "one_bit_explicit":"e2+e4+e6 plus V94 h(G), with r=(sum_v e7(G-v)^2 - 8*sum_v tree(G-v)) mod 127 and fixed residue-coloring mask.",
                "three_bit_pair":"e2+e6 exact maximum class 7 (V100).",
                "four_bit_pair":"e2+e4 exact maximum class 10 (V91).",
                "six_bit_single":"e4 exact maximum class 57 (V90/V90.1).",
                "zero_bit_complete":"five inclusion-minimal complete 5-field subsets (V75).",
            },
            "proof_dependency_map":{
                "V75":"pure atomic minimum field count = 5",
                "V90":"single-field exact/lower-bound closure; e4 max 57",
                "V90.1":"correct generic class-rank proof using full V83 globally-injective key F; numerical single-field results unchanged",
                "V91":"e2+e4 exact pair max 10",
                "V92":"triple max 2 for e2+e4+e5/e6; e2+e4+tree exact max 4",
                "V94":"explicit one-bit e2+e4+e6 construction",
                "V96":"all pairs + arbitrary 1 bit impossible; min fields at 1 bit =3",
                "V98":"all pairs + arbitrary 2 bits impossible; min fields at 2 bits =3",
                "V100":"e2+e6 exact max 7; min fields at 3 bits =2",
            },
            "claim_safe_statements":[
                "On the complete finite n=10 catalog and within the explicit atomic deleted-card family {e1,...,e9,tree}, the exact minimum atomic-field counts for auxiliary budgets b=0,...,6 are [5,3,3,2,2,2,1].",
                "The first auxiliary-bit budget that permits a two-field atomic base is exactly 3 bits; e2+e6 achieves this with maximum collision class 7.",
                "The first auxiliary-bit budget that permits a single atomic field is exactly 6 bits; e4 achieves this with maximum collision class 57.",
                "With one auxiliary bit, three atomic fields are necessary and sufficient; V94 gives an explicit finite-n=10 realization on e2+e4+e6.",
            ],
            "do_not_claim":[
                "No statement here proves a general graph-isomorphism algorithm or complexity bound.",
                "No statement here resolves the Reconstruction Conjecture.",
                "No statement here is proved for n>10.",
                "The frontier is relative to the explicit atomic family {e1,...,e9,tree}.",
                "Novelty/priority relative to the literature is not established by these certificates alone.",
            ],
            "next_research_phase":[
                "Freeze the 0..6 frontier and stop serial full-catalog scans unless a specific theorem gap is identified.",
                "Consolidate all obstruction witnesses into a compact atlas keyed by field count and bit budget.",
                "Search for a more natural mask-free realization of the V94 one-bit channel.",
                "Prepare a standalone reproducibility bundle and proof-dependency document.",
                "Run a literature/novelty review before publication claims.",
                "Only then prepare controlled GitHub/publication updates."
            ],
            "elapsed_seconds":time.time()-started,
        }

        outdir=HERE/f"V101_COUNTING_REVOLUTION_GRAPH10_INFORMATION_FRONTIER_CONSOLIDATION_{time.strftime('%Y%m%d_%H%M%S')}"
        outdir.mkdir()

        (outdir/"INFORMATION_FRONTIER_THEOREM.json").write_text(
            json.dumps(theorem,indent=2),encoding="utf-8"
        )

        with (outdir/"information_frontier_0_to_6_bits.csv").open("w",encoding="utf-8",newline="") as f:
            fields=["aux_bits","capacity_states","minimum_atomic_fields","achieving_base","lower_bound","upper_bound","certificate"]
            w=csv.DictWriter(f,fieldnames=fields,lineterminator="\n")
            w.writeheader()
            w.writerows(frontier)

        (outdir/"PROOF_DEPENDENCY_MAP.json").write_text(
            json.dumps(theorem["proof_dependency_map"],indent=2),encoding="utf-8"
        )

        claims="# Claim-safe statements\n\n"
        for x in theorem["claim_safe_statements"]:
            claims+=f"- {x}\n"
        claims+="\n# Do not claim\n\n"
        for x in theorem["do_not_claim"]:
            claims+=f"- {x}\n"
        (outdir/"PAPER_READY_CLAIMS.md").write_text(claims,encoding="utf-8")

        md="""# Counting Revolution V101 — finite n=10 information-frontier consolidation

This package freezes the exact atomic-field / auxiliary-bit frontier for
budgets 0 through 6.

| auxiliary bits | exact minimum atomic fields | witness |
|---:|---:|---|
| 0 | 5 | V75 five-field complete subsets |
| 1 | 3 | V94 `e2+e4+e6+h` |
| 2 | 3 | V92 `e2+e4+tree`, max class 4 |
| 3 | 2 | V100 `e2+e6`, max class 7 |
| 4 | 2 | V91 `e2+e4`, max class 10 |
| 5 | 2 | V91 `e2+e4`, max class 10 |
| 6 | 1 | V90/V90.1 `e4`, max class 57 |

Thus the exact vector is:

`[5,3,3,2,2,2,1]`

for auxiliary budgets `b=0,...,6`.

The important thresholds are:

- first budget allowing 3 fields: **1 bit**
- first budget allowing 2 fields: **3 bits**
- first budget allowing 1 field: **6 bits**

The result is exact only for the complete finite `n=10` graph catalog and
the explicit deleted-card atomic family `{e1,...,e9,tree}`.
"""
        (outdir/"INFORMATION_FRONTIER_THEOREM.md").write_text(md,encoding="utf-8")

        roadmap="# Next phase\n\n"
        for i,x in enumerate(theorem["next_research_phase"],1):
            roadmap+=f"{i}. {x}\n"
        (outdir/"NEXT_PHASE_ROADMAP.md").write_text(roadmap,encoding="utf-8")

        (outdir/"source_provenance.json").write_text(
            json.dumps({k.lower():{"bytes":v["bytes"],"sha256":v["sha"]} for k,v in CERTS.items()},indent=2),
            encoding="utf-8"
        )

        (outdir/"environment.json").write_text(
            json.dumps({"platform":platform.platform(),"python":sys.version,"logical_cpu_count":os.cpu_count()},indent=2),
            encoding="utf-8"
        )

        import shutil
        shutil.copy2(Path(__file__),outdir/"independent_graph10_information_frontier_consolidation_v101.py")

        entries=[]
        for fp in sorted(outdir.iterdir()):
            if fp.name!="v101_manifest.json":
                entries.append({"path":fp.name,"bytes":fp.stat().st_size,"sha256":sha256_file(fp)})
        (outdir/"v101_manifest.json").write_text(
            json.dumps({"version":VERSION,"result":"OK","files":entries},indent=2),encoding="utf-8"
        )

        zout=HERE/f"{outdir.name}.zip"
        with zipfile.ZipFile(zout,"w",zipfile.ZIP_DEFLATED,allowZip64=True) as z:
            for fp in sorted(outdir.iterdir()):
                z.write(fp,fp.name)

        print("="*78)
        print("COUNTING REVOLUTION GRAPH10 INFORMATION FRONTIER CONSOLIDATION V101")
        print("[SOURCE CERTIFICATES] 9 / 9 exact")
        print("[FRONTIER b=0..6]",[r["minimum_atomic_fields"] for r in frontier])
        print("[THRESHOLD -> 2 FIELDS] 3 bits")
        print("[THRESHOLD -> 1 FIELD] 6 bits")
        print("[STATUS] FRONTIER 0..6 CLOSED")
        print("[ZIP]",zout)
        print("="*78)
        return 0

    except Exception as exc:
        try:
            if outdir is not None:
                (outdir/"ERROR.json").write_text(
                    json.dumps({"version":VERSION,"result":"ERROR","error":str(exc),"traceback":traceback.format_exc()},indent=2),
                    encoding="utf-8"
                )
        except Exception:
            pass
        print("[FATAL]",exc)
        traceback.print_exc()
        return 1

if __name__=="__main__":
    raise SystemExit(main())
